F_gorro_multi <- function(
    datos,                # vector o data.frame
    filtro = 5,
    waveletn = "DaubLeAsymm",
    j0 = 2,
    j1 = NULL,
    auto_j1 = TRUE,
    max_j1 = 6,
    ventana_volatilidad = 7
){
  # Validar datos de entrada
  if (is.vector(datos)) {
    datos <- data.frame(Serie = datos)
  }
  
  if (!is.data.frame(datos)) stop("Los datos deben ser vector o data.frame.")
  
  # Lista para guardar resultados de cada columna
  resultado <- list()
  
  # Iterar sobre cada columna
  for (colname in names(datos)) {
    
    # Extraer serie
    serie <- as.numeric(unlist(datos[[colname]]))
    
    # Verificar longitud potencia de 2
    n <- length(serie)
    if (!log2(n) %% 1 == 0) {
      warning("La longitud no es potencia de 2. Recortando al máximo menor potencia de 2.")
      m <- 2^floor(log2(n))
      serie <- serie[1:m]
    }
    
    # Descomposición inicial
    decom_base <- wd(serie, filter.number = filtro, family = waveletn)
    
    # Selección automática del nivel
    if (auto_j1) {
      mse_list <- numeric()
      for (j in (j0+1):max_j1) {
        temp_decom <- nullevels(decom_base, (j-1):(nlevelsWT(decom_base)-1))
        temp_thres <- threshold(temp_decom, levels = (j0-1):(j-2),
                                type = "soft", policy = "sure", by.level=TRUE)
        temp_hatf <- wr(temp_thres, start.level = j-1)
        mse <- mean((serie - temp_hatf)^2, na.rm=TRUE)
        mse_list <- c(mse_list, mse)
      }
      opt_j1 <- (j0+1):max_j1
      j1 <- opt_j1[which.min(mse_list)]
    }
    
    # Reconstrucción final con j1 seleccionado
    decom <- nullevels(decom_base, (j1-1):(nlevelsWT(decom_base)-1))
    decom_thres <- threshold(decom, levels = (j0-1):(j1-2),
                             type = "soft", policy = "sure", by.level=TRUE)
    hatf <- wr(decom_thres, start.level = j1-1)
    
    # Calcular retornos y volatilidad
    retornos <- c(NA, diff(serie)/head(serie,-1))
    volatilidad <- zoo::rollapply(retornos, width=ventana_volatilidad, FUN=sd, fill=NA, align="right")
    retorno_medio <- mean(retornos, na.rm=TRUE)
    
    # Guardar resultados
    resultado[[colname]] <- list(
      curva_estimada = hatf,
      resumen_curva = summary(hatf),
      caracteristicas_procesamiento = list(
        filtro_usado = filtro,
        wavelet_usada = waveletn,
        nivel_j0 = j0,
        nivel_j1 = j1
      ),
      indicadores_volatilidad = list(
        retornos = retornos,
        volatilidad_movil = volatilidad,
        retorno_medio = retorno_medio
      )
    )
  }
  
  class(resultado) <- "F_gorro_multi_output"
  return(resultado)
}
